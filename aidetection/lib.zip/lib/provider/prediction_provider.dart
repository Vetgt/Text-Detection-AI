import 'package:flutter/material.dart';
import '../server/api_server.dart';

class PredictionProvider with ChangeNotifier {
  final ApiService _api = ApiService();

  String? result;
  double? confidence;
  bool isLoading = false;

  Future<void> predictText(String text) async {
    isLoading = true;
    notifyListeners();

    try {
      final res = await _api.predict(text);
      result = res['label'];
      confidence = res['confidence'];
    } catch (e) {
      result = "Error";
      confidence = 0;
    }

    isLoading = false;
    notifyListeners();
  }
}
