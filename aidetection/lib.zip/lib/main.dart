import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'provider/prediction_provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => PredictionProvider())],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  final TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<PredictionProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text("AI Detector")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller,
              decoration: InputDecoration(labelText: "Enter text"),
            ),
            SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {
                provider.predictText(controller.text);
              },
              child: Text("Predict"),
            ),

            SizedBox(height: 20),

            if (provider.isLoading)
              CircularProgressIndicator()
            else if (provider.result != null)
              Column(
                children: [
                  Text("Result: ${provider.result}"),
                  Text("Confidence: ${provider.confidence}"),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
